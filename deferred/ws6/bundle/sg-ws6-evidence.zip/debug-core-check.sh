#!/usr/bin/env bash
# Runs the offline serial core test suite in the TEST profile (debug assertions on, overflow checks on, opt-level 3). Usage: debug-core-check.sh <tree> <log>
set -uo pipefail
SRC=$(cd "$1" && pwd); LOG=$2; T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
export RUSTUP_TOOLCHAIN=stable CARGO_TARGET_DIR="$T/target" PYTHONDONTWRITEBYTECODE=1
cp -a "$SRC/." "$T/tree" && cd "$T/tree" && rm -f rust-toolchain.toml Cargo.lock shadowgrav-core/Cargo.lock
python3 -I - <<'PY'
p='Cargo.toml'; s=open(p).read(); open(p,'w').write(s.replace('members = ["shadowgrav-core", "shadowgrav-ui"]','members = ["shadowgrav-core"]'))
p='shadowgrav-core/Cargo.toml'; s=open(p).read()
s=s.replace('default = ["parallel"]','default = []').replace('parallel = ["dep:rayon"]','parallel = []').replace('vendored-libm = ["dep:libm"]','vendored-libm = []')
s=s.replace('libm = { version = "0.2", optional = true }\n','').replace('rayon = { version = "1.8", optional = true }\n','')
open(p,'w').write(s)
PY
cargo test --offline --workspace > "$LOG" 2>&1; echo "EXIT=$?" >> "$LOG"; tail -1 "$LOG"
grep '^test result' "$LOG" | awk '{p+=$4;f+=$6;i+=$8} END{print "suites="NR" passed="p" failed="f" ignored="i}'
