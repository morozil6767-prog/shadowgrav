#!/usr/bin/env bash
# Offline serial-core verification of a shadowgrav source tree. No registry access needed.
# It builds a SCRATCH copy in which the two optional registry dependencies (rayon, libm) are removed and the workspace is
# reduced to shadowgrav-core. That equals `--no-default-features`. It does NOT test: rayon (parallel) mode, vendored-libm,
# or anything in shadowgrav-ui. Usage: offline-core-check.sh <source-tree> <log-dir>
set -uo pipefail
SRC=$(cd "$1" && pwd); LOG=$(mkdir -p "$2" && cd "$2" && pwd); T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
export RUSTUP_TOOLCHAIN=stable CARGO_TARGET_DIR="$T/target" SHADOWGRAV_SGRUN="$T/target/release/sgrun" PYTHONDONTWRITEBYTECODE=1
cp -a "$SRC/." "$T/tree" && cd "$T/tree" && rm -f rust-toolchain.toml Cargo.lock shadowgrav-core/Cargo.lock
python3 -I - <<'PY'
p='Cargo.toml'; s=open(p).read(); open(p,'w').write(s.replace('members = ["shadowgrav-core", "shadowgrav-ui"]','members = ["shadowgrav-core"]'))
p='shadowgrav-core/Cargo.toml'; s=open(p).read()
s=s.replace('default = ["parallel"]','default = []').replace('parallel = ["dep:rayon"]','parallel = []').replace('vendored-libm = ["dep:libm"]','vendored-libm = []')
s=s.replace('libm = { version = "0.2", optional = true }\n','').replace('rayon = { version = "1.8", optional = true }\n','')
open(p,'w').write(s)
PY
rustc --version --verbose > "$LOG/toolchain.txt"; cargo --version >> "$LOG/toolchain.txt"; cargo clippy --version >> "$LOG/toolchain.txt"
run() { n=$1; shift; "$@" > "$LOG/$n.log" 2>&1; echo "EXIT=$?" >> "$LOG/$n.log"; echo "$n: $(tail -1 "$LOG/$n.log")"; }
run test            cargo test   --release --offline --workspace
run test-ignored    cargo test   --release --offline --workspace -- --ignored
run clippy          cargo clippy --release --offline --workspace --all-targets -- -D warnings
RUSTDOCFLAGS="-D warnings" run doc cargo doc --release --offline --workspace --no-deps
run repro-hash      cargo run    --release --offline -p shadowgrav-core --bin sgrun -- repro-hash
run verify-spec-a   cargo run    --release --offline -p shadowgrav-core --bin verify -- spec-a
( cd python && run python-tests python3 -I -m pytest -q -p no:cacheprovider tests )
mv "$LOG/python-tests.log" "$LOG/python-tests.log" 2>/dev/null
for f in test test-ignored; do echo "$f: $(grep '^test result' "$LOG/$f.log" | awk '{p+=$4;f+=$6;i+=$8} END{print "suites="NR" passed="p" failed="f" ignored="i}')"; done
grep -E '^combined' "$LOG/repro-hash.log"
