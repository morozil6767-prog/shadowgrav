# Cross-check report (seed 20261107, 58 geometries, oracle grid (192, 768, 96) and (384, 1536, 192))

Oracle self-estimate (max over geometries of |fine - coarse| / |F|): 2.44e+00

Maximum discrepancy per quantity, relative (derived: a, beta, tau_c, A_eff; pair: closed form vs direct 1-D integral; total: vs sky integral; corr = total - pair, relative to |total|). `refused` = engine returned an error.

| class | tier | geometries | refused | derived | pair | total | corr | max leaves | cap hits |
|---|---|---|---|---|---|---|---|---|---|
| A sparse | standard | 10 | 0 | 2.8e-15 | 1.4e-15 | 2.1e-13 | 2.1e-13 | 0 | 0 |
| A sparse | validation | 10 | 0 | 2.8e-15 | 1.4e-15 | 2.1e-13 | 2.1e-13 | 0 | 0 |
| A sparse | graded | 10 | 0 | 2.8e-15 | 1.4e-15 | 2.1e-13 | 2.1e-13 | 0 | 0 |
| A sparse | certified | 2 | 0 | 2.8e-15 | 1.3e-15 | 2.1e-13 | 2.1e-13 | 0 | 0 |
| B partial overlap | standard | 12 | 0 | 2.8e-15 | 1.5e-15 | 3.6e-03 | 3.6e-03 | 2,701 | 0 |
| B partial overlap | validation | 12 | 0 | 2.8e-15 | 1.5e-15 | 5.1e-05 | 5.1e-05 | 1,043,769 | 0 |
| B partial overlap | graded | 12 | 0 | 2.8e-15 | 1.5e-15 | 1.3e-06 | 1.3e-06 | 31,018,815 | 0 |
| B partial overlap | certified | 2 | 0 | 6.0e-16 | 4.7e-16 | 7.5e-14 | 7.5e-14 | 0 | 0 |
| C deep overlap | standard | 12 | 0 | 2.8e-15 | 9.3e-15 | 8.6e-03 | 8.6e-03 | 9,686 | 0 |
| C deep overlap | validation | 12 | 0 | 2.8e-15 | 9.3e-15 | 2.4e-04 | 2.4e-04 | 3,625,716 | 0 |
| C deep overlap | graded | 12 | 0 | 2.8e-15 | 9.3e-15 | 1.5e-05 | 1.5e-05 | 70,202,781 | 0 |
| C deep overlap | certified | 2 | 0 | 2.8e-15 | 1.0e-15 | 2.2e-06 | 2.2e-06 | 161,950,874 | 0 |
| D near contact | standard | 12 | 0 | 3.0e-15 | 1.8e-15 | 7.1e-03 | 7.1e-03 | 2,676 | 0 |
| D near contact | validation | 12 | 0 | 3.0e-15 | 1.8e-15 | 8.8e-05 | 8.8e-05 | 829,188 | 0 |
| D near contact | graded | 12 | 0 | 3.0e-15 | 1.8e-15 | 4.0e-06 | 4.0e-06 | 23,109,093 | 0 |
| D near contact | certified | 2 | 0 | 2.8e-15 | 1.8e-15 | 1.9e-06 | 1.9e-06 | 50,494,342 | 0 |
| E interior | standard | 12 | 0 | 2.9e-15 | 5.1e-15 | 2.8e+00 | 2.8e+00 | 5,738 | 0 |
| E interior | validation | 12 | 0 | 2.9e-15 | 5.1e-15 | 9.2e-01 | 9.2e-01 | 1,417,539 | 0 |
| E interior | graded | 12 | 0 | 2.9e-15 | 5.1e-15 | 9.6e-01 | 9.6e-01 | 52,817,141 | 0 |
| E interior | certified | 2 | 0 | 2.8e-15 | 1.6e-15 | 2.5e-05 | 2.5e-05 | 49,415,934 | 0 |
| ALL | standard | 58 | 0 | 3.0e-15 | 9.3e-15 | 2.8e+00 | 2.8e+00 | 9,686 | 0 |
| ALL | validation | 58 | 0 | 3.0e-15 | 9.3e-15 | 9.2e-01 | 9.2e-01 | 3,625,716 | 0 |
| ALL | graded | 58 | 0 | 3.0e-15 | 9.3e-15 | 9.6e-01 | 9.6e-01 | 70,202,781 | 0 |
| ALL | certified | 10 | 0 | 2.8e-15 | 1.8e-15 | 2.5e-05 | 2.5e-05 | 161,950,874 | 0 |

Worst three geometries per tier (total):
- standard: geometry 49 (E interior, n=4, tau0=20.0): total 2.79e+00, oracle err 2.4e+00
- standard: geometry 53 (E interior, n=3, tau0=20.0): total 4.68e-02, oracle err 1.0e-01
- standard: geometry 27 (C deep overlap, n=4, tau0=20.0): total 8.62e-03, oracle err 5.1e-05
- validation: geometry 49 (E interior, n=4, tau0=20.0): total 9.20e-01, oracle err 2.4e+00
- validation: geometry 53 (E interior, n=3, tau0=20.0): total 3.38e-03, oracle err 1.0e-01
- validation: geometry 57 (E interior, n=3, tau0=20.0): total 1.63e-03, oracle err 8.9e-03
- graded: geometry 49 (E interior, n=4, tau0=20.0): total 9.60e-01, oracle err 2.4e+00
- graded: geometry 53 (E interior, n=3, tau0=20.0): total 3.70e-03, oracle err 1.0e-01
- graded: geometry 57 (E interior, n=3, tau0=20.0): total 1.70e-03, oracle err 8.9e-03
- certified: geometry 48 (E interior, n=3, tau0=5.0): total 2.50e-05, oracle err 1.9e-04
- certified: geometry 30 (C deep overlap, n=3, tau0=5.0): total 2.19e-06, oracle err 1.0e-05
- certified: geometry 54 (E interior, n=3, tau0=0.5): total 1.91e-06, oracle err 3.6e-06
