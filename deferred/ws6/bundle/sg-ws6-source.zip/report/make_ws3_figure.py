"""WS3 convergence figure: |R - R_exact| against leaves for test (c), ungraded (report/data/convergence.txt, f_s = 4e-4)
versus the graded ladder (report/data/ws3_graded.csv, kappa and f_v halved together). Reads data only; invents nothing.
Usage: python3 report/make_ws3_figure.py  ->  report/figures/ws3_convergence.png"""
import csv, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

here = os.path.dirname(os.path.abspath(__file__))
SURF, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
C_UNGR, C_GR = "#2a78d6", "#eb6834"  # categorical slots 1 and 2 of the reference palette

ung = {}  # tau -> {leaves: err}
for line in open(os.path.join(here, "data", "convergence.txt")):
    if line.startswith("#") or not line.strip():
        continue
    p = line.split()
    tau, fs, leaves, err = int(float(p[0])), float(p[2]), int(p[4]), float(p[8])
    if fs == 4e-4 and leaves > 500_000:
        ung.setdefault(tau, {})[leaves] = err
rows = list(csv.DictReader(open(os.path.join(here, "data", "ws3_graded.csv"))))
LADDER = [("0.01", "0.25", "15"), ("0.005", "0.125", "15"), ("0.0025", "0.0625", "15"), ("0.00125", "0.03125", "15")]
TIER = ("0.0025", "0.125", "15")

def pick(tau, key):
    for r in rows:
        if (r["f_v"], r["grade"], r["ell_cap"]) == key and float(r["f_s"]) == 4e-4 and int(float(r["tau"])) == tau:
            return int(r["leaves"]), abs(float(r["err_signed_R_minus_Rexact"]))
    raise KeyError((tau, key))

plt.rcParams.update({"font.size": 10, "axes.edgecolor": INK2, "text.color": INK, "axes.labelcolor": INK2,
                     "xtick.color": INK2, "ytick.color": INK2})
fig, axs = plt.subplots(1, 3, figsize=(12.6, 4.3), sharey=True, facecolor=SURF)
for ax, tau in zip(axs, (1, 5, 20)):
    ax.set_facecolor(SURF)
    ax.grid(True, which="major", color=GRID, lw=0.8); ax.set_axisbelow(True)
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    xs = sorted(ung[tau]); ax.plot(xs, [ung[tau][x] for x in xs], "-o", color=C_UNGR, lw=2, ms=7, mfc=SURF, mew=2,
                                   label="ungraded (existing tiers)")
    g = [pick(tau, k) for k in LADDER]
    ax.plot([a for a, _ in g], [b for _, b in g], "--s", color=C_GR, lw=2, ms=7, label="graded ladder")
    tl, te = pick(tau, TIER)
    ax.plot([tl], [te], "*", color=INK, ms=15, mec=SURF, mew=1.2, label="graded tier (preset)")
    ax.axhline(1e-6, color=INK2, lw=1.2, ls=":")
    ax.text(0.98, 1.2e-6, "1e-6 target", transform=ax.get_yaxis_transform(), ha="right", va="bottom", color=INK2, fontsize=9)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_title(f"tau = {tau}", color=INK, loc="left", fontsize=11)
    ax.set_xlabel("leaves per evaluation")
axs[0].set_ylabel("|R - R_exact|")
axs[0].legend(loc="lower left", frameon=False, fontsize=9)
fig.suptitle("Test (c): quadrature error against cost, ungraded vs graded refinement (rim cap 15, f_s = 4e-4)",
             x=0.01, ha="left", color=INK, fontsize=12)
fig.tight_layout(rect=(0, 0, 1, 0.94))
out = os.path.join(here, "figures", "ws3_convergence.png")
fig.savefig(out, dpi=200, facecolor=SURF); print("wrote", out)
