# CHANGES 18: WS2c verification pass

Scope: no physics, spec text, tolerance or test edits. No `#[allow]` added. No lockfile or manifest change in this pass (the eframe 0.33 migration is the WS2c session's work).

| Change | Why | Checked |
|---|---|---|
| `rustfmt` applied to `shadowgrav-ui/src/skyview.rs` and `view3d.rs` (formatting only, 32 patch lines) | `cargo fmt --check` failed on the two lines the eframe 0.33 migration lengthened (`ColorImage::new`, `rect_stroke`) | [RAN] `rustfmt --edition 2021 --check` over all 49 `.rs` files: exit 1 before (4 diffs, only those two files), exit 0 after |
| New `DEPENDENCIES.md` | Docs said nothing about advisory, licence or floor status after the upgrade | Facts from the lockfile and cited advisories; unverified items listed in the file |
| Removed one marketing adjective from three places (`AUDIT_2026-11-06.md` x2, `CHANGES_11_instrument_surface.md`) | The project contract forbids marketing language anywhere in the repo | Case-insensitive grep for the contract's forbidden words (see WS prompt) over `*.md *.rs *.toml *.yml` finds nothing afterwards |
| `shadowgrav-ui/DESIGN.md`: one clause marking the "eframe 0.29" API review as historical | Avoid a contradictory version number | Read |

Not changed: `rust-version` values (no executed boundary check was possible), `rust-toolchain.toml`, `ci.yml`, `deny.toml`.
