# Dependencies, advisories, licences and Rust floor

Status after the WS2c eframe 0.33 migration. Evidence tags: [RAN] executed, [READ] inspected, [CITED] from a source with URL, [INFERRED] reasoning.
Nothing in this file is a hosted-CI result. `cargo audit` and `cargo deny` were **not** run on the current lockfile; see "Unverified".

## Direct dependencies

| Crate | Declared | Locked | Notes |
|---|---|---|---|
| shadowgrav-core: `rayon` (optional, `parallel`, default on) | `1.8` | 1.12.0 | `shadowgrav-core/Cargo.lock` unchanged by WS2c [READ] |
| shadowgrav-core: `libm` (optional, `vendored-libm`) | `0.2` | 0.2.16 | same |
| shadowgrav-ui: `eframe` | `0.33` | 0.33.3 | egui, egui-winit, egui-wgpu, epaint 0.33.3; wgpu 27.0.1; winit 0.30.13 |

## Accessibility

`eframe` is used with its default features, so AccessKit stays compiled in [READ]: `Cargo.lock` contains `accesskit` 0.21.1, `accesskit_winit` 0.29.2,
`accesskit_unix` 0.17.2, `accesskit_macos` 0.22.2 and `accesskit_windows` 0.29.2. That the screen-reader tree is actually exposed at run time has **not**
been checked.

## Advisory status of the locked graph

| Advisory | Crate in lock | Status | Evidence |
|---|---|---|---|
| RUSTSEC-2026-0194, RUSTSEC-2026-0195 (vulnerabilities, fixed in quick-xml >= 0.41.0) | `quick-xml` 0.41.0 only (build-time, via `wayland-scanner`). 0.30.0 is gone. | Expected clear | [READ] lockfile; fixed-version statement from the WS2b `cargo-deny` log |
| RUSTSEC-2026-0192 (unmaintained) | `ttf-parser` 0.25.1, via `ab_glyph` and `epaint` | **Still present, no fixed version** | [READ] lockfile; [CITED] https://osv.dev/vulnerability/RUSTSEC-2026-0192 (affected from 0.0.0-0, no fixed event) |
| RUSTSEC-2024-0436 (unmaintained) | `paste` 1.0.15, now only via `metal` 0.32.0 and `wgpu-hal` (macOS target); the `accesskit_windows` path is gone | **Still present, no fixed version** | [READ] lockfile; [CITED] https://osv.dev/vulnerability/RUSTSEC-2024-0436 |
| RUSTSEC-2026-0370 / -0371 / -0372 (unmaintained) | `zvariant` 5.15.1, `zbus_names` 4.3.5, `zvariant_derive` 5.15.1, via `zbus` 5.19.0 and `accesskit_unix` 0.17.2 | **Still present, all versions flagged** | [READ] lockfile; [CITED] https://osv.dev/vulnerability/RUSTSEC-2026-0370 , .../RUSTSEC-2026-0371 , .../RUSTSEC-2026-0372 (affected from 0.0.0-0, no fixed event; advisory text says the crates were merged into `zbus` 6.0.0) |

[INFERRED] With `deny.toml` as written (`unmaintained = "all"`, `ignore = []`), `cargo deny check advisories` is expected to **fail** on those five unmaintained crates even
after the upgrade. Upgrading eframe removed the two quick-xml vulnerabilities; it did not and cannot remove the unmaintained crates, because upstream has not
replaced them in this version line. No ignore entry has been added. Options for the owner: accept and record them with an expiry, scope the policy with
`unmaintained = "workspace"` (checks only direct dependencies), or move to a GUI stack whose graph no longer contains them.

## Licences

`deny.toml` allows the permissive SPDX ids the graph used at WS2b plus `OFL-1.1`, and allows `LicenseRef-UFL-1.0` only for the crate `epaint_default_fonts` (the owner's WS2c
decision). It does not licence shadowgrav itself; there is still no project `LICENSE`. [UNVERIFIED] `cargo deny check licenses` was not re-run on the 0.33 graph, so
any licence introduced by the 72 added crate versions is unchecked.

## Rust floor

| Item | Value | Basis |
|---|---|---|
| `shadowgrav-core` `rust-version` | 1.80 | WS2b run (`cargo check` on 1.80.0, rayon 1.12.0 rejects 1.79.0). The core lock is byte-identical before and after WS2c (SHA-256 `a205fb17...d0cd5`), so this floor was not re-measured and did not need to be. |
| `shadowgrav-ui` `rust-version` | 1.88 (unchanged) | **Necessary**: `icu_*` 2.4.0 and `image` 0.25.10 need 1.88 (WS2b cargo output) and the same versions are in the new lock. **Sufficiency after eframe 0.33 is not independently verified**: the WS2c session reported a clean 1.88.0 build, but supplied no log. The 1.87-fails / 1.88-passes boundary has not been re-run on the new lock. |
| `uuid` | pinned to 1.10.0 in `Cargo.lock` only | Reported by the WS2c session: 1.29.1 needs rustc 1.89. A bare `cargo update` can move it and break the 1.88 build. The MSRV-aware resolver (`resolver = "3"`) would express this in the manifest; not applied. |

## Unverified

- `cargo audit` / `cargo deny` on the WS2c lockfile (the sandbox used for this note has no crates.io access).
- UI build, UI tests, clippy and doc on the UI crate with eframe 0.33.
- Rust floor of the UI after the upgrade (1.87 and 1.88 boundary).
- Vendored-libm digest on the current tree.
- Any macOS or Windows build, and any run-time accessibility check.
